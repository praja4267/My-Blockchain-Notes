"use strict";
const helper = require("./contractHelper");

async function main(
  org,
  fabricUserName,
  channelName,
  chainCodeName,
  smartContractName,
  role,
  firstName,
  lastName,
  gender,
  dob,
  phone,
  email,
  address,
  pinCode
) {}

module.exports.execute = main;
