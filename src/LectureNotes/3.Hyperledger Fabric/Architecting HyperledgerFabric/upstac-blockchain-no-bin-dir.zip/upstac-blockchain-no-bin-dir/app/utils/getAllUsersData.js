"use strict";
const helper = require("./contractHelper");

async function main(
  org,
  fabricUserName,
  channelName,
  chainCodeName,
  smartContractName
) {}

module.exports.execute = main;
