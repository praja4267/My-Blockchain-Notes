"use strict";
const helper = require("./contractHelper");

async function main(
  org,
  fabricUserName,
  channelName,
  chainCodeName,
  smartContractName,
  phone,
  newDetailsPayload
) {}

module.exports.execute = main;
