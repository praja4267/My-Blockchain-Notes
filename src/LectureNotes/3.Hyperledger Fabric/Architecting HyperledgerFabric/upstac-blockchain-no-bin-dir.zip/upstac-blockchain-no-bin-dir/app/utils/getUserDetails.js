"use strict";
const helper = require("./contractHelper");

async function main(
  org,
  fabricUserName,
  channelName,
  chainCodeName,
  smartContractName,
  phone
) {}

module.exports.execute = main;
