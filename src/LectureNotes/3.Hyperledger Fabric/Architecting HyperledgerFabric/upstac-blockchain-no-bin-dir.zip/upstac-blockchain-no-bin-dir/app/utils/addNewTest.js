"use strict";
const helper = require("./contractHelper");

async function main(
  org,
  fabricUserName,
  channelName,
  chainCodeName,
  smartContractName,
  testId,
  phone,
  description
) {}

module.exports.execute = main;
