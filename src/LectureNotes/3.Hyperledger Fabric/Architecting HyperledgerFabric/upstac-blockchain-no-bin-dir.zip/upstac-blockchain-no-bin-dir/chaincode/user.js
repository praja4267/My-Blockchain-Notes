// Dependencies
const { Contract } = require("fabric-contract-api");
const keys = require("./keys");

// Main Chaincode Class
class UserChainCode extends Contract {
  // Provide a custom name to refer to this smart contract

  /* ****** Contract Functions - Starts ***** */

  // This is a basic user defined function used at the time of instantiating the smart contract
  // to print the success message on console

  // To validate if one hospital is not updating other hospital Records
  validateUpdater(ctx, initiator) {
    const initiatorID = ctx.clientIdentity.getX509Certificate();
    if (initiatorID.issuer.organizationName.trim() !== initiator) {
      throw new Error(
        "Not authorized to initiate the transaction: " +
          initiatorID.issuer.organizationName +
          " not authorised to initiate this transaction"
      );
    }
  }

  /**
   * Create User
   * @param ctx - The transaction Context object
   * @param role - Role of the user Patient/Tester/Doctor/Govt/Insurance
   * @param firstName - First Name of the user
   * @param lastName - Last Name Id of the user
   * @param gender - Gender of the user
   * @param dob - Date of Birth of the user
   * @param phone - Phone Number of the user
   * @param email - Email Id of the user
   * @param address - Address of the user
   * @param pinCode - Pin Code of the user
   */
  async addNewUser(
    ctx,
    role,
    firstName,
    lastName,
    gender,
    dob,
    phone,
    email,
    address,
    pinCode
  ) {
    // Reference
    // Payload
    // Check if user already exists
    // Check if data exists
    // Get All Users
    // First User
    // Convert the JSON object to a buffer and send it to blockchain for storage
    // Save in Blockchain
    // Return Added Data
  }

  /**
   * Get User Details
   * @param ctx - The transaction Context object
   * @param phone - User Phone Number
   */
  async getUserDetails(ctx, phone) {
    // Reference
    // Get User Data
    // Check if data exists
    // Parse Data into JSON
    // Response
  }

  /**
   * Update User Details
   * @param ctx - The transaction Context object
   * @param phone - User Phone Number
   * @param newDetailsPayload - New Details payload that needs to be updated. Example -> {address:abc}
   */
  async updateUserDetails(ctx, phone, newDetailsPayload) {
    // Reference
    // Get User Data
    // Check if data exists
    // Parse Data into JSON
    // Parse Data into JSON
    // Can not update below fields
    // Update Details
    // Convert the JSON object to a buffer and send it to blockchain for storage
    // Add in DB
    // Response
  }

  /**
   * Create Test
   * @param ctx - The transaction Context object
   * @param testId - Test Id
   * @param phone - Phone Number of the Patient
   * @param description - Test Description
   */
  async addNewTest(ctx, testId, phone, description) {
    // Reference

    // Payload

    // Get Patient Data
    // Check if phone Number is registered to Patient

    // Check for duplicate Test ID

    // Get All Tests

    // First User

    // Get Patient Previous Mapping Data

    // First Test

    // Convert the JSON object to a buffer and send it to blockchain for storage
    // Save in Blockchain

    // Return Added Data
    return newTestPayload;
  }

  /**
   * Update Test
   * @param ctx - The transaction Context object
   * @param testId - Test ID
   * @param newDetailsPayload - New Details payload that needs to be updated. Example -> {status:"COMPLETED"}
   */
  async updateTestDetails(ctx, testId, newDetailsPayload) {
    // Reference
    // Get User Data
    // Check if data exists
    // Parse Data into JSON
    // Validate if same org is updating the record
    // Can not update if status is completed
    // Parse Data into JSON
    // Can not update Bewlo fields
    // Update Details
    // Convert the JSON object to a buffer and send it to blockchain for storage
    // Add in DB
    // Response
  }

  /**
   * Get Test Details
   * @param ctx - The transaction Context object
   * @param testId - Test Id
   */
  async getTestDetails(ctx, testId) {
    // Reference
    // Get User Data
    // Check if data exists
    // Parse Data into JSON
    // Response
  }

  /**
   * Get Patient Test Details
   * @param ctx - The transaction Context object
   * @param phone - Patient Phone Number
   */
  async getPatientTestDetails(ctx, phone) {
    // Reference
    // Get User Data
    // Check if data exists
    // Parse Data into JSON
    // Iterate Over Test
    // Response
  }

  /**
   * Get All Users Data
   * @param ctx - The transaction Context object
   */
  async getAllUsersData(ctx) {
    // Reference
    // Get All Request Data
    // Check if data exists
    // Iterate Over Requests
    // Response
  }

  /**
   * Get All Test Data
   * @param ctx - The transaction Context object
   */
  async getAllTestData(ctx) {
    // Reference
    // Get All Request Data
    // Check if data exists
    // Iterate Over Requests
    // Response
  }

  /* ****** Contract Functions - Ends ***** */
}

module.exports = UserChainCode;
