// Dependencies
const { Contract } = require("fabric-contract-api");
const keys = require("./keys");

// Main Chaincode Class
class InsuranceChainCode extends Contract {
  constructor() {
    // Provide a custom name to refer to this smart contract
    super("org.upstac.insurance");
  }

  /* ****** Contract Functions - Starts ***** */

  // This is a basic user defined function used at the time of instantiating the smart contract
  // to print the success message on console
  async instantiate(ctx) {
    console.log("User ChainCode Instantiated");
  }

  // To validate if only hospital is approving request and insurance is creating request
  validateOrg(ctx, initiator) {
    const initiatorID = ctx.clientIdentity.getX509Certificate();
    if (initiatorID.issuer.organizationName.trim() !== initiator) {
      throw new Error(
        "Not authorized to initiate the transaction: " +
          initiatorID.issuer.organizationName +
          " not authorised to initiate this transaction"
      );
    }
  }

  /**
   * Request Price for test
   * @param ctx - The transaction Context object
   * @param testId - Test Id
   */
  async requestPrice(ctx, testId) {}

  /**
   * Get All Price Requests
   * @param ctx - The transaction Context object
   */
  async getAllPriceRequests(ctx) {}

  /**
   * Request Price for test
   * @param ctx - The transaction Context object
   * @param testId - Test Id
   */
  async getPriceRequest(ctx, testId) {}

  /**
   * Approve Price Request
   * @param ctx - The transaction Context object
   * @param testId - Test Id
   * @param price - Test price
   */
  async approvePriceRequest(ctx, testId, price) {}

  /* ****** Contract Functions - Ends ***** */
}

module.exports = InsuranceChainCode;
