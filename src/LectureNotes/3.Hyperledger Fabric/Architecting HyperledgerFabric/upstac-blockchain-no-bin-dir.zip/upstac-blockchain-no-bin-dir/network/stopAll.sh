# Stop Insurance Network
./insurance-network.sh down

# Stop Initial Network
./network.sh down